data1 = 10
print( "\n",data1 ,"is  ", type(data1))

data2 = "10"
print( "\n'",data2 ,"'is ", type(data2))

data3 = "10.0"
print( "\n'",data3 ,"'is ", type(data3))

var4 = 10.4
print( "\n",var4 ,"is ", type(var4))

data5 = "Python"
print( "\n",data5 ,"is ", type(data5))

data6 = 1j
print( "\n",data6 ,"is ", type(data6))

data7 = ["apple", "banana", "cherry"]
print( "\n",data7 ,"is ", type(data7))

data8 = ("apple", "banana", "cherry")
print( "\n",data8 ,"is ", type(data8))

data9 = range(6)
print( "\n",data9 ,"is ", type(data9))

data10 = {"name" : "John", "age" : 36}
print( "\n",data10 ,"is ", type(data10))

data11 = {"apple", "banana", "cherry"}
print( "\n",data11 ,"is ", type(data11))

data12 = frozenset({"apple", "banana", "cherry"})
print( "\n",data12 ,"is ", type(data12))

var13 = True
print( "\n",var13 ,"is ", type(var13))

data14 =  b"Hello"
print( "\n",data14 ,"is ", type(data14))

data15 = bytearray(5)
print( "\n",data15 ,"is ", type(data15))

data16 = memoryview(bytes(5))
print( "\n",data16 ,"is ", type(data16))
