num1 = 10
num2 = 20

result = num1 + num2 
print(result)
