a = 5
b = 2

divide = a/b
subtraction = a-b
multiplication = a*b
intigerdivision = a//b
exponent = a**b

print("divide = ",divide,"\nsubtraction = ",subtraction, "\nmultiplication = ", multiplication, "\nintigerdivision = ", intigerdivision, "\nexponent = ", exponent)