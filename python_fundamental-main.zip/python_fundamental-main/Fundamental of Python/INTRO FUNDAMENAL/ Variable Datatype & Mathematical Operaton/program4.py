name = input("What is your name? :")
print("Welcome ",name)  