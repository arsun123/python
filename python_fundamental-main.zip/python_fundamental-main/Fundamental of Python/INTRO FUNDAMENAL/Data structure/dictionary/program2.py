marks = {"DH2001": 76, "DH3001": 88, "DH4001": 85}
print(marks)
print(marks["DH2001"])
