bd_division_info = {}
bd_division_info["Barisal"] = {"district": 6, "upazila": 39, "union":333}
bd_division_info["Chittagong"] = {"district": 11, "upazila": 97, "union":336}
bd_division_info["Dhaka"] = {"district": 13, "upazila": 93, "union":1833}
bd_division_info["Khulna"] = {"district": 10, "upazila": 59, "union":270}
bd_division_info["Mymensingh"] = {"district": 4, "upazila": 34, "union":350}

print(bd_division_info.keys())

for key,value in bd_division_info.items():
    # print(divission,bd_division_info[divission]["upazila"])
    # print(bd_division_info[divission])
    print(key)
    print(value)





