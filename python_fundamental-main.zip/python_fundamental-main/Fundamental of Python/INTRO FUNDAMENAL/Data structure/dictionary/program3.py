empty_dict = {}
print(empty_dict)
print(type(empty_dict))
empty_dict[66656] = "software development"
empty_dict[66657] = "android development"

print(empty_dict)

#dictionary is not mutable . so its value never changed after assign

