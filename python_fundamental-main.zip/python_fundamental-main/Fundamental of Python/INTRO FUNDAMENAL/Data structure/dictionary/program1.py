# #result sheet of math in list
# marks = [77,44,56,55,67,87]
# roll = int(input("roll:"))
# print("result ",marks[roll-1])

# #result sheet of math and english list
# marks2 = [[77,99],[66,88],[88,89]]
# roll2 = int(input("roll2:"))
# print("result2 ",marks2[roll2-1])

#let's try it dictionary
marks = {1: 77, 2:78, 3:88, 4:74}
print(type(marks))
print(marks[1])





