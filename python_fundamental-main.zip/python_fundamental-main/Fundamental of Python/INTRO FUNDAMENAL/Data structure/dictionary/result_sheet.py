marks = {"DH101":{"bangla":67, "math":75},"DH102":{"bangla":87, "math":95}}
print(marks)
print(marks["DH101"]["bangla"],marks["DH102"]["bangla"])