numbers = (10,20,30,40)
n1,n2,n3,n4 = numbers
print(n1)
print(n2)
print(n3)
print(n4)
print(n2)
print(type(n1))
t = n1,n2
print(type(t))

