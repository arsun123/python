list_1 = [1,2,3]
list_2 = [4,5,6]

list_1.extend(list_2)

print(list_1)
print(list_2)