li = [1,3,3,4,5,6,6,6]
print(li.count(3))

