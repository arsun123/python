fruits = ['apple','bananna','mango']
print(fruits)
fruits.pop()
print(fruits)
fruits.pop(0)
print(fruits)