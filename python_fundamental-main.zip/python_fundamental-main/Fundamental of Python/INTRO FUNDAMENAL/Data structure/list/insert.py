todo_list = ["lunch","dinner"]
print(todo_list)
todo_list.insert(0,"break fast")
               #(index,  item  )
print(todo_list)
todo_list.insert(2,"playing cricket")
print(todo_list)