num_list = [4,9,5,1,3,2]
print(num_list)
num_list.sort()
print(num_list)