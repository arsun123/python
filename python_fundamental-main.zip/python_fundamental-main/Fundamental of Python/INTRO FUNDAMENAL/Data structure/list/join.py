li = ["a","b","c","d"]
print(li)
str = "".join(li)
print(str)
str = ",".join(li)
print(str)
str = "_".join(li)
print(str)

