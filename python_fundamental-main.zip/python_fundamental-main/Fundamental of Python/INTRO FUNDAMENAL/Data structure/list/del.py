li = [2,3,4,5,56]
print(li)
del(li[4])
print(li)