fruits_list = ["apple","banana","coconut"]
print(fruits_list)
fruits_list.remove("coconut")
print(fruits_list)