li1 = [10, 20, 30]
li2 = [4, 3, 2]
add_list = li1 + li2
print(add_list)

mult_list = li1 * 2``
print(mult_list)

