num_list = [8,1,4,2,6,3]
print(num_list)
num_list.sort()
print(num_list)
num_list.reverse()
print(num_list)