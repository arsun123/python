li = [] #empty list
for item in range(10):
    li.append(item)
print(li)
