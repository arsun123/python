li = [1,2,3,4,5,6,7,8]
square_list = [ x * x for x in li]
print(square_list)