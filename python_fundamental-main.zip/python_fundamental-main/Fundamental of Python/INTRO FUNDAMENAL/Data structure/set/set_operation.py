set1 = {1,2,3,4,5}
set2 = {2,4,6,8}

intersec_set = set1 & set2 #intersection operation
print(intersec_set)

union_set = set1 | set2
print(union_set) #union operation

unique_set = set1 ^ set2
print(unique_set)

sub_set = set1 - set2
print(sub_set)





