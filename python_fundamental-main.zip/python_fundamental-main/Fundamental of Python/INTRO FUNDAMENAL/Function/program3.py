def myfunc(x):
    print("inside func ",x)
    x = 10
    print("inside func ", x)

x = 20
myfunc(x)
print(x)

