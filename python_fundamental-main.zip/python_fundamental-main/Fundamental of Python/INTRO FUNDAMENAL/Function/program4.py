def myfnc(y =10):
    print("y = ", y)

x = 20
myfnc(x)
myfnc()