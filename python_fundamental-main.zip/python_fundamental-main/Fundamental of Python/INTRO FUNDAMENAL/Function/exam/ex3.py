def multiplication_table(num = 1):
    for i in range(1,11):
        result = num * i
        print(num," X ",i,"=",result)

multiplication_table(6)
    

