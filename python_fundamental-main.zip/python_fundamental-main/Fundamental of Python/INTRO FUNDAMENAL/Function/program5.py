def myfnc(x, y = 10, z = 0):
    print("x =",x, "y=",y,"z=",z)

x = 5
y = 6
z = 7
myfnc(x,y,z)