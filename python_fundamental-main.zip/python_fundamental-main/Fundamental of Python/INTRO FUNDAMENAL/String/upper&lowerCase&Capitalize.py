c1 ="bangladesh"
c_up = c1.upper()
print(c_up)
c_low = c1.lower()
print(c_low)
c_cap = c1.capitalize()
print(c_cap)