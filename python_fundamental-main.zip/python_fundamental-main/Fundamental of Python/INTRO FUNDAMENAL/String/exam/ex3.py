str1 = input("input: ")
str2 = str1[::-1]

if str1 == str2:
    print("Palindrome")
else:
    print("Not palindrome")
