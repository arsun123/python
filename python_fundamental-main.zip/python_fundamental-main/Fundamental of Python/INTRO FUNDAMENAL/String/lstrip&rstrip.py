text = " this is a string. "
print(text)
text.lstrip()
print(text)
text.rstrip()
print(text)

#open in terminal
