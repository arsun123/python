str = "I am a student"
words = str.split()
print(words)
for word in words:
    print(word)