name = "pyhton"
find_value = name.find('o')
print(find_value)

find_value = name.find('f')
print(find_value)



