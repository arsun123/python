str = "The name of my country is Bangladesh"
str_count = str.count("is")
print(str_count)