str = "a quick brown fox jumps over the lazy dog"
for i in "abcdefghijklmnopqrstuvwxyz":
    print(i, str.count(i))

