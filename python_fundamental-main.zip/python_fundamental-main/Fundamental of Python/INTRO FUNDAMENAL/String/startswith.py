str = "python"
start = str.startswith("p")
print(start)