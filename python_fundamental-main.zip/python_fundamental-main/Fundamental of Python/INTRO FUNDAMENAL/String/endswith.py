str = "python"
end = str.endswith("n")
print(end)

name = "Mr. Anderson"
if name.startswith("Mr."):
    print("Dear sir")
