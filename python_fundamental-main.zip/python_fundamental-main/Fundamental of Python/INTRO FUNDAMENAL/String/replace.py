old_version = "python 2.0"
print("Old version:",old_version)

new_version = old_version.replace("2.0", "3.10")
print("New version:",new_version)
