import re


result = 0

for i in range(2, 20, 3):
    i += 1
    result += i

print(result)