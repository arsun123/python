result = 0

for num in range(5, 101, 5):
    print(num)
    result += num
print("Sum: ", result)