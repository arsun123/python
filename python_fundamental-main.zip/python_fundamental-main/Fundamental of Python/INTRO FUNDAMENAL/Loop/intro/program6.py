result = 0

for i in range(3, 5):
    i += 1
    result += i

print(result)