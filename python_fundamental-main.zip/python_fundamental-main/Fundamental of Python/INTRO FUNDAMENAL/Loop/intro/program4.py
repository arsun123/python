import re


result = 0

for i in range(50):
    result += 1
print(result)