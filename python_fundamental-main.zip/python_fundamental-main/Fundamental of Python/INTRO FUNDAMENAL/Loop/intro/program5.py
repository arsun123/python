result  = 0

for i in range(50):
    i += 1
    result += i
print(result)