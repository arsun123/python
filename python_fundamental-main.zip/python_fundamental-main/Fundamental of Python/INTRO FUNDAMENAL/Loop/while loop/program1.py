i = 0
while i< 6:
    print(i)
    i += 1

print("second loop")
j = 10
while j >= 0:
    j -= 1
    print(j)