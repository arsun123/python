n = int(input("Number:"))

m = 1
while m <= 10:
    print(n, "x", m, "=", n*m)
    m+=1
