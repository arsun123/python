myFriend = ["sadik","babu", "tamim"]

for i in myFriend:
    print(i,"is my friend")