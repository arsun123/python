myList = list(range(10))
print(myList)

mylist2 = list(range(2,11,2))
print(mylist2)