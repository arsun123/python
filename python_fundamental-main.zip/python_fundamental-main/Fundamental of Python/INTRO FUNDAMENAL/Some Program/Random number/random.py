import random
print(random.random())

print(random.randint(10,50))