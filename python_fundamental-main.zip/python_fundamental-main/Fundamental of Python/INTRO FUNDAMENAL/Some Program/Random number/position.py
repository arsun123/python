import turtle

print(turtle.position())

turtle.forward(100)
print(turtle.position())
