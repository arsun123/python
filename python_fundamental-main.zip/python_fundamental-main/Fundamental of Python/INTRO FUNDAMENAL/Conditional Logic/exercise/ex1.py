num = int(input("Number: "))

if(num >= 0):
    print("Positive")
else:
    print("Negative")
    