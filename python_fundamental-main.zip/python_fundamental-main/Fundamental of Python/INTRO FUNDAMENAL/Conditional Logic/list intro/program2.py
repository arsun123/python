my_friends_list = ["Sadik", "Babu", "Afifa", "Akaid", "Tamjid", "Shakil"]

print(my_friends_list)
print("Length = ",len(my_friends_list))

""" 
    len() is a function thats count
    here how many items on the
    list 
"""

check = "Afifa" in my_friends_list
print(check)

check = "Tamim" in my_friends_list
print(check)

"""
The 'in' keyword has two purposes:

The 'in' keyword is used to check if a value is present in a sequence (list, range, string etc.).

The 'in' keyword is also used to iterate through a sequence in a for loop
"""
