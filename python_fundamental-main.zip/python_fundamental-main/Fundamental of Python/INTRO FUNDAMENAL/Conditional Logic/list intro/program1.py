number_list = [1,3,5,7,9,11,13,15,17,19]

print("number list =", number_list,"\n")

#index, start from 0

print(number_list[0])
print(number_list[5])
print(number_list[7])


