a = 10
b = 34

print(a == b)
print(a < b)
print(a > b)
print(a != b)
print(a <= b)
print(a >= b)



