country1 = "Bangladesh"
country2 = "bangladesh"
country3 = "Bangladesh"


print(country1 == country2)
print(country1 == country3)

