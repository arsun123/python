x = 5; y = 10
print('The value of x is {} and y is {}'.format(x,y))