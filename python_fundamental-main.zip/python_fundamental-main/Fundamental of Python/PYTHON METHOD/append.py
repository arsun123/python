my_list = ["laptop","phone","python book"]
print(my_list)
my_list.append("C book")
print(my_list)

#list is mutbale . for  this reasons when we add a new value on 
#the list , the main list will be changed
