num = 10
print("id =",id(num))