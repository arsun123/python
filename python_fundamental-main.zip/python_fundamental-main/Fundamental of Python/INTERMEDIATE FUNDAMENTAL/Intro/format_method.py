x = 5; y = 10
print('The value of x is {} and y is {}'.format(x,y))

print('Hello {name}, {greeting}'.format(greeting = 'Good morning', name = 'John'))

x = 12.3456789
print('The value of x is %3.2f' %x)