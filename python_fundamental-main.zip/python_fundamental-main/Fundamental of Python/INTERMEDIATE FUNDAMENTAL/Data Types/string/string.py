count = 0
for letter in "Hello world":
    if (letter == 'l'):
        count+= 1
print(count,'letters found')