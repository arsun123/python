str = 'cold'

list_enumerate = list(enumerate(str))
print("list(enumerate(str) = ",list_enumerate,")")

#character count
print("len(str) = ",len(str),")")