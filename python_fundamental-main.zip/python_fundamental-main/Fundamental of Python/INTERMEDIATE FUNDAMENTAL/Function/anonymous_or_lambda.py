double = lambda x:x*2
print(double(10))