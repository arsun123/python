import config

config.a = 10
config.b = "alphabet"
