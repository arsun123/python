import config
import update

print(config.a)
print(config.b)