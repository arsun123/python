# import math
import math as m

num = 25
# square_num = math.sqrt(10)
square_num = m.sqrt(num)

print(square_num)

print(dir(m))