from math import pi, sin, sqrt
# from math import * #bad practic


num = sin(pi/2)
print(num)
print(sqrt(25))