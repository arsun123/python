> if we need to install packages like pandas
``` pip install pandas ```

> if we need to install especific version of a package
``` pip install requests==2.21.0 ```

> if you wanna see all the package on your coumputer
```pip list```