def get_boss_info():
    print("I am the Boss")