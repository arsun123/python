def get_enemy_info():
    print("I am the enemy")