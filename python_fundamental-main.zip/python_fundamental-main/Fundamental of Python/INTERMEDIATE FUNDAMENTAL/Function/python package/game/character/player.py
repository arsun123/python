def get_player_info():
    print("I am the main player.")