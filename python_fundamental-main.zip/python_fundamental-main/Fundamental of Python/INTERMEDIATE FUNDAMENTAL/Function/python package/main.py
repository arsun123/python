import game.character.player
from game.character import boss
from game.character.enemy import get_enemy_info

game.character.player.get_player_info()
boss.get_boss_info()
get_enemy_info()